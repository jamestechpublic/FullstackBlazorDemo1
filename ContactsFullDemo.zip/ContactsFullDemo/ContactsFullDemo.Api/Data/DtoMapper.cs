﻿using ContactsFullDemo.Api.Models;
using ContactsFullDemo.Shared.DTO;
using Microsoft.AspNetCore.Identity;

namespace ContactsFullDemo.Api.Data
{
    public static class DtoMapper
    {
        #region ToDto
        public static ContactDto ToContactDto(Contact contact)
        {
            return new ContactDto
            {
                Id = contact.Id,
                ContactName = contact.ContactName,
                Phone = contact.Phone,
                Email = contact.Email
            };
        }

        public static GroupDto ToGroupDto(Group group)
        {
            return new GroupDto
            {
                Id = group.Id,
                GroupName = group.GroupName,
                ContactCount = group.ContactCount
            };
        }

        public static ContactGroupDto ToContactGroupDto(ContactGroup contactGroup)
        {
            return new ContactGroupDto
            {
                Id = contactGroup.Id,
                ContactId = contactGroup.ContactId,
                GroupId = contactGroup.GroupId
            };
        }

        #endregion

        #region ToModel
        public static Contact ToContact(ContactDto contactDto)
        {
            return new Contact
            {
                Id = contactDto.Id,
                ContactName = contactDto.ContactName,
                Phone = contactDto.Phone,
                Email = contactDto.Email
            };
        }

        public static Group ToGroup(GroupDto groupDto)
        {
            return new Group
            {
                Id = groupDto.Id,
                GroupName = groupDto.GroupName,
                ContactCount = groupDto.ContactCount
            };
        }

        public static ContactGroup ToContactGroup(ContactGroupDto contactGroupDto)
        {
            return new ContactGroup
            {
                Id = contactGroupDto.Id,
                ContactId = contactGroupDto.ContactId,
                GroupId = contactGroupDto.GroupId
            };
        }

        #endregion
    }
}
