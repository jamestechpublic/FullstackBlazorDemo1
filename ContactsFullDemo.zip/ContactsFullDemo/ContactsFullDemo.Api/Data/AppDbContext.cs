﻿using ContactsFullDemo.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace ContactsFullDemo.Api.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Contact> Contacts { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<ContactGroup> ContactGroups { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Ensure ContactId + GroupId is unique (no duplicate memberships)
            modelBuilder.Entity<ContactGroup>()
                .HasIndex(cg => new { cg.ContactId, cg.GroupId })
                .IsUnique();

            // Relationships
            modelBuilder.Entity<ContactGroup>()
                .HasOne(cg => cg.Contact)
                .WithMany(c => c.ContactGroups)
                .HasForeignKey(cg => cg.ContactId)
                .OnDelete(DeleteBehavior.Cascade);  // will delete if contact is deleted, but do not delete contact

            modelBuilder.Entity<ContactGroup>()
                .HasOne(cg => cg.Group)
                .WithMany(g => g.ContactGroups)
                .HasForeignKey(cg => cg.GroupId)
                .OnDelete(DeleteBehavior.Cascade); // will delete if group is deleted, but do not delete group
        }
    }
}
