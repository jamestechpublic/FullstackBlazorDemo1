﻿namespace ContactsFullDemo.Api.Models
{ 
    public class Group
    {
        public int Id { get; set; }
        public string GroupName { get; set; } = string.Empty;
        public int ContactCount { get; set; }

        // Navigation property
        public ICollection<ContactGroup> ContactGroups { get; set; } = new List<ContactGroup>();
    }
}
