﻿namespace ContactsFullDemo.Api.Models
{
    public class Contact
    {
        public int Id { get; set; }
        public string ContactName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;

        // Navigation property
        public ICollection<ContactGroup> ContactGroups { get; set; } = new List<ContactGroup>();
    }
}
