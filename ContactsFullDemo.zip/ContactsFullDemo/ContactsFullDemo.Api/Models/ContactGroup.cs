﻿namespace ContactsFullDemo.Api.Models
{
    public class ContactGroup
    {
        public int Id { get; set; }
        public int ContactId { get; set; }
        public int GroupId { get; set; }

        // Navigation properties
        public Contact Contact { get; set; } = null!;
        public Group Group { get; set; } = null!;
    }
}
