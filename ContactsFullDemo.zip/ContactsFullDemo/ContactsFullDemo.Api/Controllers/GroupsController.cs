﻿using ContactsFullDemo.Api.Services;
using ContactsFullDemo.Shared.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ContactsFullDemo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GroupsController(IGroupService _service) : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> GetAllGroups()
        {
            try
            {
                var groups = await _service.GetAllAsync();
                return Ok(groups);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetGroupById(int id)
        {
            try
            {
                var group = await _service.GetByIdAsync(id);
                if (group == null) return NotFound();
                return Ok(group);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddGroup([FromBody] GroupDto groupDto)
        {
            try
            {
                var createdGroup = await _service.AddAsync(groupDto);
                return CreatedAtAction(nameof(GetGroupById), new { id = createdGroup.Id }, createdGroup);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (DbUpdateException ex) when (IsDuplicateError(ex))
            {
                return Conflict("A group with the same name already exists.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateGroup([FromBody] GroupDto groupDto)
        {
            try
            {
                var updatedGroup = await _service.UpdateAsync(groupDto);
                return Ok(updatedGroup);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (DbUpdateException ex) when (IsDuplicateError(ex))
            {
                return Conflict("A group with the same name already exists.");
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGroup(int id)
        {
            try
            {
                await _service.DeleteAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        bool IsDuplicateError(DbUpdateException ex)
        {
            if (ex.InnerException?.Message.Contains("UNIQUE constraint failed") == true) return true;

            return false;
        }
    }
}
