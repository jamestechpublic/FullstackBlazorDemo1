﻿using ContactsFullDemo.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ContactsFullDemo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactGroupsController(IContactGroupService _service) : ControllerBase
    {
        [HttpGet("groupsbycontactid/{contactId}")]
        public async Task<IActionResult> GetGroupsByContactIdAsync(int contactId)
        {
            try
            {
                var groups = await _service.GetGroupsByContactIdAsync(contactId);
                if (groups == null) return NotFound();
                return Ok(groups);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet("contactsbygroupid/{groupId}")]
        public async Task<IActionResult> GetContactsByGroupIdAsync(int groupId)
        {
            try
            {
                var contacts = await _service.GetContactsByGroupIdAsync(groupId);
                if (contacts == null) return NotFound();
                return Ok(contacts);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPost("contact/{contactId}/group/{groupId}")]
        public async Task<IActionResult> AddContactToGroupAsync(int contactId, int groupId)
        {
            try
            {
                await _service.AddContactToGroupAsync(contactId, groupId);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpDelete("contact/{contactId}/group/{groupId}")]
        public async Task<IActionResult> RemoveContactFromGroupAsync(int contactId, int groupId)
        {
            try
            {
                await _service.RemoveContactFromGroupAsync(contactId, groupId);
                return NoContent();
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
