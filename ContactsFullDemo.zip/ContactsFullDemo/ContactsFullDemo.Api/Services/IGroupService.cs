﻿using ContactsFullDemo.Shared.DTO;

namespace ContactsFullDemo.Api.Services
{
    public interface IGroupService
    {
        Task<IEnumerable<GroupDto>> GetAllAsync();
        Task<GroupDto?> GetByIdAsync(int id);
        Task<GroupDto> AddAsync(GroupDto group);
        Task<GroupDto> UpdateAsync(GroupDto group);
        Task DeleteAsync(int id);
    }
}
