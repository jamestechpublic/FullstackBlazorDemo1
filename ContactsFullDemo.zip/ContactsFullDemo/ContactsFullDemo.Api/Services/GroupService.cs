﻿using ContactsFullDemo.Api.Data;
using ContactsFullDemo.Shared.DTO;
using ContactsFullDemo.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;

namespace ContactsFullDemo.Api.Services
{
    public class GroupService(AppDbContext _context) : IGroupService
    {
        public async Task<IEnumerable<GroupDto>> GetAllAsync()
        {
            return await _context.Groups.Select(g => DtoMapper.ToGroupDto(g)).ToListAsync();
        }

        public async Task<GroupDto?> GetByIdAsync(int id)
        {
            var group = await _context.Groups.FindAsync(id);
            return group == null ? null : DtoMapper.ToGroupDto(group);
        }

        public async Task<GroupDto> AddAsync(GroupDto group)
        {
            ValidateGroup(group); // throw exception if invalid
            FormatGroup(group);

            Group newGroup = DtoMapper.ToGroup(group);
            
            _context.Groups.Add(newGroup);
            await _context.SaveChangesAsync();

            return DtoMapper.ToGroupDto(newGroup);
        }

        public async Task<GroupDto> UpdateAsync(GroupDto group)
        {
            ValidateGroup(group); // throw exception if invalid
            FormatGroup(group);

            Group newGroup = DtoMapper.ToGroup(group);
            var existing = await _context.Groups.FindAsync(newGroup.Id);
            if (existing == null)
                throw new KeyNotFoundException($"Group with Id {newGroup.Id} not found.");

            existing.GroupName = newGroup.GroupName;
            existing.ContactCount = newGroup.ContactCount;

            _context.Groups.Update(existing);
            await _context.SaveChangesAsync();

            return DtoMapper.ToGroupDto(existing);
        }

        public async Task DeleteAsync(int id)
        {
            var group = await _context.Groups.Include(g => g.ContactGroups).FirstAsync(g => g.Id == id);

            if (group == null)
                throw new KeyNotFoundException($"Group with Id {id} not found.");

            // because of cascading delete, related ContactGroups will be removed automatically
            _context.Groups.Remove(group);     
            await _context.SaveChangesAsync();
        }

        #region Helpers

        void ValidateGroup(GroupDto group)
        {
            if (group == null)
                throw new ArgumentNullException(nameof(group));
            if (string.IsNullOrWhiteSpace(group.GroupName))
                throw new ArgumentException("Group name cannot be empty.");
        }

        void FormatGroup(GroupDto group)
        {
            // Split words, capitalize first letter, lowercase the rest
            var words = group.GroupName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            group.GroupName = string.Join(" ", words.Select(w => char.ToUpper(w[0]) + w.Substring(1).ToLower()));
        }

        #endregion
    }
}
