﻿using ContactsFullDemo.Shared.DTO;

namespace ContactsFullDemo.Api.Services
{
    public interface IContactService
    {
        Task<IEnumerable<ContactDto>> GetAllAsync();
        Task<ContactDto?> GetByIdAsync(int id);
        Task<ContactDto> AddAsync(ContactDto contact);
        Task<ContactDto> UpdateAsync(ContactDto contact);
        Task DeleteAsync(int id);
    }
}
