﻿using ContactsFullDemo.Api.Data;
using ContactsFullDemo.Api.Models;
using ContactsFullDemo.Shared.DTO;
using Microsoft.EntityFrameworkCore;

namespace ContactsFullDemo.Api.Services
{
    public class ContactService(AppDbContext _context) : IContactService
    {
        public async Task<IEnumerable<ContactDto>> GetAllAsync()
        {
            return await _context.Contacts.Select(c => DtoMapper.ToContactDto(c)).ToListAsync();
        }

        public async Task<ContactDto?> GetByIdAsync(int id)
        {
            var contact = await _context.Contacts.FindAsync(id);
            return contact == null ? null : DtoMapper.ToContactDto(contact);
        }

        public async Task<ContactDto> AddAsync(ContactDto contact)
        {
            ValidateContact(contact); // throw exception if invalid
            FormatContact(contact);

            Contact newContact = DtoMapper.ToContact(contact);

            _context.Contacts.Add(newContact);
            await _context.SaveChangesAsync();

            return DtoMapper.ToContactDto(newContact);
        }

        public async Task<ContactDto> UpdateAsync(ContactDto contact)
        {
            ValidateContact(contact); // throw exception if invalid
            FormatContact(contact);

            Contact newContact = DtoMapper.ToContact(contact);
            var existing = await _context.Contacts.FindAsync(newContact.Id);
            if (existing == null)
                throw new KeyNotFoundException($"Contact with Id {newContact.Id} not found.");

            existing.ContactName = newContact.ContactName;
            existing.Phone = newContact.Phone;
            existing.Email = newContact.Email;

            _context.Contacts.Update(existing);
            await _context.SaveChangesAsync();

            return DtoMapper.ToContactDto(existing);
        }

        public async Task DeleteAsync(int id)
        {
            var contact = await _context.Contacts.Include(g => g.ContactGroups).FirstAsync(c => c.Id == id);
            
            if (contact == null)
                throw new KeyNotFoundException($"Contact with Id {id} not found.");

            // because of cascading delete, related ContactGroups will be removed automatically
            _context.Contacts.Remove(contact);
            await _context.SaveChangesAsync();
        }

        #region Helpers

        void ValidateContact(ContactDto contact)
        {
            if (contact == null)
                throw new ArgumentNullException(nameof(contact));
            if (string.IsNullOrWhiteSpace(contact.ContactName))
                throw new ArgumentException("Contact name cannot be empty.");

            // validate phone number
            if (!string.IsNullOrWhiteSpace(contact.Phone) && 
                !System.Text.RegularExpressions.Regex.IsMatch(contact.Phone,
                                                            @"^\+?[1-9]\d{0,2}[-.\s]?\(?\d{1,4}\)?([-.\s]?\d{1,4}){1,3}$"))
                throw new ArgumentException("Invalid phone number format.");

            // validate email
            if (!string.IsNullOrWhiteSpace(contact.Email) && 
                !System.Text.RegularExpressions.Regex.IsMatch(contact.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                throw new ArgumentException("Invalid email format.");
        }

        void FormatContact(ContactDto contact)
        {
            // Split words, capitalize first letter, lowercase the rest
            var words = contact.ContactName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            contact.ContactName = string.Join(" ", words.Select(w => char.ToUpper(w[0]) + w.Substring(1).ToLower()));
        }

        #endregion
    }
}
