﻿using ContactsFullDemo.Api.Data;
using ContactsFullDemo.Api.Models;
using ContactsFullDemo.Shared.DTO;
using Microsoft.EntityFrameworkCore;

namespace ContactsFullDemo.Api.Services
{
    public class ContactGroupService(AppDbContext _context) : IContactGroupService
    {
        public async Task<IEnumerable<GroupDto>?> GetGroupsByContactIdAsync(int contactId)
        {
            var groups = await _context.ContactGroups
                .Where(cg => cg.ContactId == contactId)
                .Select(cg => DtoMapper.ToGroupDto(cg.Group))
                .ToListAsync();

            return groups;
        }

        public async Task<IEnumerable<ContactDto>?> GetContactsByGroupIdAsync(int groupId)
        {
            var contacts = await _context.ContactGroups
                .Where(cg => cg.GroupId == groupId)
                .Select(cg => DtoMapper.ToContactDto(cg.Contact))
                .ToListAsync();

            return contacts;
        }

        public async Task AddContactToGroupAsync(int contactId, int groupId)
        {
            var contactGroup = new ContactGroup
            {
                ContactId = contactId,
                GroupId = groupId
            };
            _context.ContactGroups.Add(contactGroup);
            await _context.SaveChangesAsync();
        }

        public async Task RemoveContactFromGroupAsync(int contactId, int groupId)
        {
            var contactGroup = await _context.ContactGroups
                .FirstOrDefaultAsync(cg => cg.ContactId == contactId && cg.GroupId == groupId);
            if (contactGroup != null)
            {
                _context.ContactGroups.Remove(contactGroup);
                await _context.SaveChangesAsync();
            }
        }
    }
}
