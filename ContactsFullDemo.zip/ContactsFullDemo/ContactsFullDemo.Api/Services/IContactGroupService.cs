﻿using ContactsFullDemo.Shared.DTO;

namespace ContactsFullDemo.Api.Services
{
    public interface IContactGroupService
    {
        Task<IEnumerable<GroupDto>?> GetGroupsByContactIdAsync(int contactId);
        Task<IEnumerable<ContactDto>?> GetContactsByGroupIdAsync(int groupId);
        Task AddContactToGroupAsync(int contactId, int groupId);
        Task RemoveContactFromGroupAsync(int contactId, int groupId);
    }
}
