﻿namespace ContactsFullDemo.Services
{
    public class PageState
    {
        public int SelectedGroupId { get; set; }
    }
}
