﻿using ContactsFullDemo.Shared.DTO;

namespace ContactsFullDemo.Services
{
    public class ContactService(HttpClient _http) : IContactService
    {
        public async Task<IEnumerable<ContactDto>?> GetAllContactsAsync()
        {
            return await _http.GetFromJsonAsync<IEnumerable<ContactDto>>("api/contacts");
        }

        public async Task<ContactDto?> GetContactByIdAsync(int id)
        {
            return await _http.GetFromJsonAsync<ContactDto>($"api/contacts/{id}");
        }

        public async Task<ContactDto?> AddContactAsync(ContactDto contact)
        {
            var response = await _http.PostAsJsonAsync("api/contacts", contact);
            return await ReadResponse.ReadResponseAsync<ContactDto>(response);
        }

        public async Task<ContactDto?> UpdateContactAsync(ContactDto contact)
        {
            var response = await _http.PutAsJsonAsync("api/contacts", contact);
            return await ReadResponse.ReadResponseAsync<ContactDto>(response);
        }

        public async Task DeleteContactAsync(int id)
        {
            var response = await _http.DeleteAsync($"api/contacts/{id}");
            response.EnsureSuccessStatusCode();
        }
    }
}
