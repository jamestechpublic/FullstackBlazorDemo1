﻿using ContactsFullDemo.Shared.DTO;
using static System.Net.WebRequestMethods;

namespace ContactsFullDemo.Services
{
    public class ContactGroupService(HttpClient _http) : IContactGroupService
    {
        public async Task<IEnumerable<ContactDto>?> GetContactsByGroupIdAsync(int groupId)
        {
            return await _http.GetFromJsonAsync<IEnumerable<ContactDto>?>($"api/contactgroups/contactsbygroupid/{groupId}");
        }

        public async Task<IEnumerable<GroupDto>?> GetGroupsByContactIdAsync(int contactId)
        {
            return await _http.GetFromJsonAsync<IEnumerable<GroupDto>?>($"api/contactgroups/groupsbycontactid/{contactId}");
        }

        public async Task AddContactToGroupAsync(int contactId, int groupId)
        {
            await UpdateGroupContactCountAsync(groupId, 1);

            var response = await _http.PostAsJsonAsync($"api/contactgroups/contact/{contactId}/group/{groupId}", new { });
            response.EnsureSuccessStatusCode();
        }

        public async Task RemoveContactFromGroupAsync(int contactId, int groupId)
        {
            await UpdateGroupContactCountAsync(groupId, -1);

            var response = await _http.DeleteAsync($"api/contactgroups/contact/{contactId}/group/{groupId}");
            response.EnsureSuccessStatusCode();
        }

        public async Task UpdateGroupContactCountAsync(int groupId, int delta)
        {
            var group = await _http.GetFromJsonAsync<GroupDto>($"api/groups/{groupId}");
            if (group == null)
                throw new Exception($"Cannot update contact count for Group with ID {groupId}.");

            group.ContactCount += delta;
            await _http.PutAsJsonAsync($"api/groups", group);
        }
    }
}
