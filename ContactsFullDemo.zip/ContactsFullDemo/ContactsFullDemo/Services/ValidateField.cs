﻿namespace ContactsFullDemo.Services
{
    public static class ValidateField
    {
        public static string ValidatePhone(string phone)
        {
            if (string.IsNullOrEmpty(phone)) return null; // valid

            var pattern = @"^\+?[1-9]\d{0,2}[-.\s]?\(?\d{1,4}\)?([-.\s]?\d{1,4}){1,3}$";
            if (!System.Text.RegularExpressions.Regex.IsMatch(phone, pattern))
                return "Please enter a valid phone number";

            return null; // valid
        }

        public static string ValidateEmail(string email)
        {
            if (string.IsNullOrEmpty(email)) return null; // valid

            var pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (!System.Text.RegularExpressions.Regex.IsMatch(email, pattern))
                return "Please enter a valid email address";

            return null; // valid
        }
    }
}
