﻿namespace ContactsFullDemo.Services
{
    public static class ReadResponse
    {
        public static async Task<T?> ReadResponseAsync<T>(HttpResponseMessage response)
        {
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<T>();
            }

            var errorMessage = await response.Content.ReadAsStringAsync();

            throw response.StatusCode switch
            {
                System.Net.HttpStatusCode.NotFound => new KeyNotFoundException(errorMessage),
                System.Net.HttpStatusCode.Conflict => new InvalidOperationException(errorMessage),
                System.Net.HttpStatusCode.BadRequest => new ArgumentException(errorMessage),
                _ => new HttpRequestException($"Unexpected error {response.StatusCode}: {errorMessage}")
            };
        }
    }
}
