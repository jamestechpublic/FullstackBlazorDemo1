﻿using ContactsFullDemo.Shared.DTO;

namespace ContactsFullDemo.Services
{
    public interface IContactGroupService
    {
        Task<IEnumerable<ContactDto>?> GetContactsByGroupIdAsync(int groupId);
        Task<IEnumerable<GroupDto>?> GetGroupsByContactIdAsync(int contactId);
        Task AddContactToGroupAsync(int contactId, int groupId);
        Task RemoveContactFromGroupAsync(int contactId, int groupId);
        Task UpdateGroupContactCountAsync(int groupId, int delta);
    }
}
