﻿using ContactsFullDemo.Shared.DTO;

namespace ContactsFullDemo.Services
{
    public interface IGroupService
    {
        Task<IEnumerable<GroupDto>?> GetAllGroupsAsync();
        Task<GroupDto?> GetGroupByIdAsync(int id);
        Task<GroupDto?> AddGroupAsync(GroupDto group);
        Task<GroupDto?> UpdateGroupAsync(GroupDto group);
        Task DeleteGroupAsync(int id);
    }
}
