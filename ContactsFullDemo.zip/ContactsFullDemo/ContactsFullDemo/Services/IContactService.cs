﻿using ContactsFullDemo.Shared.DTO;

namespace ContactsFullDemo.Services
{
    public interface IContactService
    {
        Task<IEnumerable<ContactDto>?> GetAllContactsAsync();
        Task<ContactDto?> GetContactByIdAsync(int id);
        Task<ContactDto?> AddContactAsync(ContactDto contact);
        Task<ContactDto?> UpdateContactAsync(ContactDto contact);
        Task DeleteContactAsync(int id);
    }
    
}
