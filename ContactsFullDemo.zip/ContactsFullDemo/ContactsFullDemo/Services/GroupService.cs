﻿using ContactsFullDemo.Shared.DTO;

namespace ContactsFullDemo.Services
{
    public class GroupService(HttpClient _http) : IGroupService
    {
        public async Task<IEnumerable<GroupDto>?> GetAllGroupsAsync()
        {
            return await _http.GetFromJsonAsync<IEnumerable<GroupDto>>("api/groups");
        }

        public async Task<GroupDto?> GetGroupByIdAsync(int id)
        {
            return await _http.GetFromJsonAsync<GroupDto>($"api/groups/{id}");
        }

        public async Task<GroupDto?> AddGroupAsync(GroupDto group)
        {
            var response = await _http.PostAsJsonAsync("api/groups", group);
            return await ReadResponse.ReadResponseAsync<GroupDto>(response);
        }

        public async Task<GroupDto?> UpdateGroupAsync(GroupDto group)
        {
            var response = await _http.PutAsJsonAsync("api/groups", group);
            return await ReadResponse.ReadResponseAsync<GroupDto>(response);
        }

        public async Task DeleteGroupAsync(int id)
        {
            var response = await _http.DeleteAsync($"api/groups/{id}");
            response.EnsureSuccessStatusCode();
        }

    }
}
