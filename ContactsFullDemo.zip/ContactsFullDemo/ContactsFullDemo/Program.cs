using ContactsFullDemo.Components;
using ContactsFullDemo.Services;
using MudBlazor.Services;
using System.Net;

namespace ContactsFullDemo
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddRazorComponents().AddInteractiveServerComponents();

            builder.Services.AddMudServices();

            var cookieHandler = new HttpClientHandler { UseCookies = true, CookieContainer = new CookieContainer() };
            builder.Services.AddScoped(sp =>
            {
                var apiUrl = builder.Configuration["ApiSettings:BaseUrl"];
                cookieHandler = new HttpClientHandler { UseCookies = true, CookieContainer = new CookieContainer() };
                return new HttpClient(cookieHandler) { BaseAddress = new Uri(apiUrl) };
            });

            builder.Services.AddScoped<IGroupService, GroupService>();
            builder.Services.AddScoped<IContactGroupService, ContactGroupService>();
            builder.Services.AddScoped<IContactService, ContactService>();
            builder.Services.AddScoped<PageState>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseAntiforgery();

            app.MapStaticAssets();
            app.MapRazorComponents<App>()
                .AddInteractiveServerRenderMode();

            app.Run();
        }
    }
}
