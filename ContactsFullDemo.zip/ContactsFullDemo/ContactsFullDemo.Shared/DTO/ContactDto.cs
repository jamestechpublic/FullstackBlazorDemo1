﻿namespace ContactsFullDemo.Shared.DTO
{
    public class ContactDto
    {
        public int Id { get; set; }
        public string ContactName { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
}
