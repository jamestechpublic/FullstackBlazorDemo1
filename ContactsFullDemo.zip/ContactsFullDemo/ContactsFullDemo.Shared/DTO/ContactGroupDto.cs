﻿namespace ContactsFullDemo.Shared.DTO
{
    public class ContactGroupDto
    {
        public int Id { get; set; }
        public int ContactId { get; set; }
        public int GroupId { get; set; }
    }
}
