﻿namespace ContactsFullDemo.Shared.DTO
{
    public class GroupDto
    {
        public int Id { get; set; }
        public string GroupName { get; set; } = string.Empty;
        public int ContactCount { get; set; }
    }
}
